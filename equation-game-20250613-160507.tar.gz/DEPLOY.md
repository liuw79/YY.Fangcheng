# 学方程小游戏 - 部署指南

## 问题解决

### npm权限错误修复

如果遇到以下npm错误：
```
npm ERR! code EACCES
npm ERR! syscall mkdir
npm ERR! path /Users/liuwei/.npm/_cacache/index-v5/2f/8c
```

**解决方案：**
```bash
sudo chown -R 501:20 "/Users/liuwei/.npm"
```

✅ **已修复** - npm缓存文件夹权限问题已解决

## 自动部署

### 部署配置

- **目标服务器**: `ssh@op.gaowei.com`
- **应用端口**: `8888` (避免与现有端口5001和80冲突)
- **部署路径**: `/var/www/equation-game/current`
- **Web服务器**: Nginx
- **技术栈**: 静态HTML/CSS/JavaScript

### 使用方法

1. **确保SSH密钥配置**
   ```bash
   # 测试SSH连接
   ssh root@op.gaowei.com
   ```

2. **执行部署**
   ```bash
   ./deploy.sh
   ```

3. **访问应用**
   ```
   http://op.gaowei.com:8888
   ```

### 部署流程

1. ✅ **检查本地文件** - 验证必要文件存在
2. ✅ **创建部署包** - 打包应用文件（排除不必要文件）
3. ✅ **上传到服务器** - 通过SCP传输
4. ✅ **服务器部署** - 解压并配置文件权限
5. ✅ **配置Nginx** - 自动安装和配置Web服务器
6. ✅ **启动服务** - 重载Nginx配置

### 部署特性

#### 🔒 安全配置
- 启用安全HTTP头
- 防止XSS攻击
- 内容类型保护

#### ⚡ 性能优化
- Gzip压缩
- 静态文件缓存（1年）
- HTML文件禁用缓存

#### 🔄 版本管理
- 自动备份现有版本
- 支持快速回滚
- 时间戳标记

#### 📊 监控日志
- 访问日志：`/var/log/nginx/equation-game.access.log`
- 错误日志：`/var/log/nginx/equation-game.error.log`

### 端口分配

| 应用 | 端口 | 状态 |
|------|------|------|
| 现有应用1 | 80 | 已占用 |
| 现有应用2 | 5001 | 已占用 |
| **学方程小游戏** | **8888** | **新分配** |

### 故障排除

#### 检查服务状态
```bash
# 检查Nginx状态
ssh root@op.gaowei.com 'sudo systemctl status nginx'

# 检查端口监听
ssh root@op.gaowei.com 'sudo netstat -tlnp | grep 8888'

# 查看错误日志
ssh root@op.gaowei.com 'sudo tail -f /var/log/nginx/equation-game.error.log'
```

#### 手动重启服务
```bash
ssh root@op.gaowei.com 'sudo systemctl restart nginx'
```

#### 回滚到上一版本
```bash
ssh root@op.gaowei.com '
  cd /var/www/equation-game
  sudo rm -rf current
  sudo mv backup/backup-YYYYMMDD-HHMMSS current
  sudo systemctl reload nginx
'
```

### 开发工作流

1. **本地开发**
   ```bash
   # 启动本地服务器
   python3 -m http.server 8080
   # 访问 http://localhost:8080
   ```

2. **测试验证**
   - 确保所有游戏模块正常工作
   - 检查页面跳转功能
   - 验证响应式设计

3. **部署发布**
   ```bash
   ./deploy.sh
   ```

4. **验证部署**
   ```bash
   curl -I http://op.gaowei.com:8888
   ```

### 技术环境一致性

- ✅ **静态文件服务** - 与现有应用兼容
- ✅ **Nginx配置** - 使用标准配置模式
- ✅ **文件权限** - 遵循www-data用户规范
- ✅ **日志格式** - 统一的日志记录
- ✅ **安全策略** - 一致的安全头配置

---

## 快速命令参考

```bash
# 修复npm权限（已执行）
sudo chown -R 501:20 "/Users/liuwei/.npm"

# 部署应用
./deploy.sh

# 查看部署状态
ssh root@op.gaowei.com 'sudo systemctl status nginx'

# 查看访问日志
ssh root@op.gaowei.com 'sudo tail -f /var/log/nginx/equation-game.access.log'
```

🎯 **应用地址**: http://op.gaowei.com:8888